package Assignment2;
import java.io.*;
import java.net.Socket;
import java.util.Random;

public class TrafficLightControlSys {
    private static final String MONITOR_HOST = "localhost"; // Monitor host (local machine)
    private static final int MONITOR_PORT = 6000; // port number for the heartbeat monitor
    private static final int LIGHT_INTERVAL = 2000; // setting light switch interval for 2 seconds
    private static final String CHECKPOINT_FILE = "checkpoint.txt"; // file for storing checkpoint state

    // Enum for representing three traffic light states
    enum Light {
        RedLight, GreenLight, YellowLight
    }

    public static void main(String[] args) {
        // Create a socket connection to the monitor
        try (Socket socket = new Socket(MONITOR_HOST, MONITOR_PORT);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

            Random random = new Random();
            Light currentLight = Light.RedLight; // Initialize the traffic light to red
            int heartbeatCount = 0; // Initialize heartbeat count
            boolean failureOccurred = false; // Flag to simulate failure

            // Check if a checkpoint file exists and load state
            File checkpointFile = new File(CHECKPOINT_FILE);
            if (checkpointFile.exists()) {
                BufferedReader reader = new BufferedReader(new FileReader(checkpointFile));
                currentLight = Light.valueOf(reader.readLine()); // Load last saved light state
                heartbeatCount = Integer.parseInt(reader.readLine()); // Load last heartbeat count
                reader.close();
                System.out.println("Resumed from checkpoint with Light: " + currentLight + " and Heartbeat count: " + heartbeatCount);
            } else {
                System.out.println("Starting fresh...");
            }

            while (true) {
                // Simulate random failure with a 20% chance
                if (!failureOccurred && random.nextInt(100) < 20) {
                    failureOccurred = true;
                    System.out.println("A failure occurred in the Traffic Light System. Stopping heartbeats.");
                    // After failure, stop sending heartbeats but keep running
                }

                // Send heartbeat only if failure hasn't occurred
                if (!failureOccurred) {
                    out.println("HEARTBEAT " + heartbeatCount);
                    System.out.println("Sent heartbeat " + heartbeatCount);
                    heartbeatCount++;
                }

                // Save state to checkpoint file
                if (!failureOccurred) {
                    PrintWriter writer = new PrintWriter(new FileWriter(CHECKPOINT_FILE));
                    writer.println(currentLight); // Save current light state
                    writer.println(heartbeatCount); // Save current heartbeat count
                    writer.close();
                }

                // Switch traffic lights based on the current state
                if (!failureOccurred) {
                    switch (currentLight) {
                        case RedLight:
                            currentLight = Light.GreenLight;
                            System.out.println("Switching to GREEN light");
                            break;
                        case GreenLight:
                            currentLight = Light.YellowLight;
                            System.out.println("Switching to YELLOW light");
                            break;
                        case YellowLight:
                            currentLight = Light.RedLight;
                            System.out.println("Switching to RED light");
                            break;
                    }
                }

                Thread.sleep(LIGHT_INTERVAL); // Wait for the next light interval
            }
        } catch (IOException | InterruptedException e) {
            System.err.println("Exception: " + e.getMessage());
        }
    }
}
